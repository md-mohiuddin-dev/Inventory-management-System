package com.example.ecommerce.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.core.userdetails.*;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity  // enables @PreAuthorize
public class SecurityConfig {

    // 🔐 Authentication (Users + Roles)
    @Bean
    public UserDetailsService userDetailsService() {

        UserDetails user = User.withUsername("user")
                .password("{noop}user123")
                .roles("USER")
                .build();

        UserDetails admin = User.withUsername("admin")
                .password("{noop}admin123")
                .roles("ADMIN")
                .build();

        return new InMemoryUserDetailsManager(user, admin);
    }

    // 🔒 Authorization (Access Rules)
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())

            .authorizeHttpRequests(auth -> auth

                // 🔓 Public APIs
                .requestMatchers("/products").permitAll()

                // 🔒 Swagger only for ADMIN
                .requestMatchers(
                        "/swagger-ui/**",
                        "/v3/api-docs/**"
                ).hasRole("ADMIN")

                // 🔒 Admin APIs
                .requestMatchers("/products/delete/**").hasRole("ADMIN")

                // 🔒 User + Admin APIs
                .requestMatchers("/products/**").hasAnyRole("USER", "ADMIN")

                // 🔒 Everything else
                .anyRequest().authenticated()
            )

            // 🔐 Authentication type
            .httpBasic(Customizer.withDefaults());

        return http.build();
    }
}