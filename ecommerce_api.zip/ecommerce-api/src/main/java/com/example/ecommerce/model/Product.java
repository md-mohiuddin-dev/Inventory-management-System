package com.example.ecommerce.model;



import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity


public class Product {

	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   
	 @Schema(description = "Product ID", example = "1")
	private Long id;
	 @Schema(description = "Product Name", example = "Laptop")
    private String name;
	 @Schema(description = "Product Price", example = "50000")
	 private double price;
	public static Object withProductName(String string) {
		// TODO Auto-generated method stub
		return null;
	}

    //without  getters & setters it will print [] blank no details will be 
    //available
}
